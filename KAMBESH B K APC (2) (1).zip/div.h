#ifndef DIV_H
#define DIV_H


#include "apc.h"

int compare(dlist *head1, dlist *head2);

void append_digit(dlist **head1,dlist **tail1,dlist **head3,dlist **tail3);

void remove_leading_zeros(dlist **head, dlist **tail);

void subtract_lists(dlist *tail1,dlist *tail2,dlist **headR,dlist **tailR);

void divOperation(dlist **headDividend,dlist **tailDividend,dlist *headDivisor,dlist *tailDivisor,dlist **headQuotient,dlist **tailQuotient, int negative);

void div_op(char *op1, char *op2);

#endif
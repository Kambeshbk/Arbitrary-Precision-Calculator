#ifndef ADD_H
#define ADD_H

#include "apc.h"

void add_op(char *op1, char *op2);

void addOperation(dlist *head1, dlist *tail1, dlist *head2, dlist *tail2, int negative);  

#endif
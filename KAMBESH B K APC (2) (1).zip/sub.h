#ifndef SUB_H
#define SUB_H

#include "apc.h"

void sub_op(char *op1, char *op2);

void subtractOperation(dlist *head1, dlist *tail1,
                       dlist *head2, dlist *tail2,
                       int negative);

int compare_lists(dlist *head1, dlist *head2); 


#endif
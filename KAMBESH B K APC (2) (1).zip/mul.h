#ifndef MUL_H
#define MUL_H

#include "apc.h"

dlist *build_list_from_digits(const char *str, dlist **tail);

void strip_leading_zeros(dlist **head, dlist **tail);

void  mulOperation(dlist *headOP1, dlist *tailOP1,dlist *headOP2, dlist *tailOP2, dlist **headR, dlist **tailR);

void mul_op(const char *op1, const char *op2);


#endif